function Offspring = UpdateSwarm(Swarm,K)

    Global	= GLOBAL.GetObj();
    N       = Global.N;
    D       = Global.D;
    
    ParticleVel = Swarm.adds(zeros(N,D));
    ParticlePosition = Swarm.decs;
    
%     ArchiveDecs = Archive.decs;
    
    %% SOM Training on Archive
    if Global.M == 2
        msize = [100 1];
    else
        msize = [10 10];
    end
    sMap = som_randinit(ParticlePosition,'msize', msize);
    sMap  = som_batchtrain(sMap,ParticlePosition,'radius',[1,0.8,0.5,0.3,0.2,0.1],'trainlen',6,'neigh','gaussian');
    NeighMat = som_neighbors(sMap,K);
    
    Bestmu = som_bmus(sMap,ParticlePosition);
    
    %% Get Leaders
    Pbest = [];
    Gbest = [];
    for i = 1:N
        Neuro = Bestmu(i);      
        %% pbest
        curPbest = sMap.codebook(Neuro,:);
        Pbest = [Pbest;curPbest];
        
        %% gbest
        Neigh = find(NeighMat(Neuro,:)==1);
        curGbest = sMap.codebook(randsample(Neigh,1),:);
        Gbest = [Gbest;curGbest];
    end
    
    %% PSO
    Gen = Global.gen;
    MaxGen = Global.maxgen;
    W  = 0.4*(1-Gen/ MaxGen);
    %% Update of Particle with random vectors
%     OffVel= zeros(N,D);
%     Offspring = zeros(N,D);
%     for i = 1:N
%         a1 =  rand(1,D);
%         a2 = -1 + 2*rand(1,D);
%         OffVel(i,:)    = W.*ParticleVel(i,:) + a1.*(Pbest(i,:)-ParticlePosition(i,:)) + a2.*(Gbest(i,:)-ParticlePosition(i,:));
%         Offspring(i,:) = ParticlePosition(i,:) + OffVel(i,:);
%     end
    
    %% Parameter Settings
    a1     = repmat(rand(N,1),1,D);
    a2     = repmat((-1 + 2*rand(N,1)),1,D);
    %% Update of Particle
   
    OffVel    = W.*ParticleVel + a1.*(Pbest-ParticlePosition) + a2.*(Gbest-ParticlePosition);
    Offspring = ParticlePosition + OffVel;

    
    %% Deterministic back
    proM=1;
    disM=20;
    
    Lower  = repmat(Global.lower,N,1);
    Upper  = repmat(Global.upper,N,1);
    
    

    Site  = rand(N,D) < proM/D;
    mu    = rand(N,D);
    temp  = Site & mu<=0.5;
    Offspring       = min(max(Offspring,Lower),Upper);
    Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                      (1-(Offspring(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
    temp = Site & mu>0.5; 
    Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                      (1-(Upper(temp)-Offspring(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
    
    Offspring = INDIVIDUAL(Offspring,OffVel);
end