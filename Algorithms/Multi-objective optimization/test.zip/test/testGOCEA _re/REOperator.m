function y = REOperator(MatingPool,pop,Problem,centroid)
% Generate offsprings by RE Operators

    % %% Parameter setting
    % if nargin < 2
    %     K = 5;
    % end
    % PopDec = Population.decs;
    % [N,D]  = size(PopDec);
    % M      = length(Population(1).obj);
    % % Global = Population.objs;
    % disM = 20;
    % 
    % %% Modeling
    % [Partition,Model,probability] = LocalPCA(PopDec,M,K);
    % 
    % %% Reproduction
    % OffspringDec = [];
    % % Generate new trial solutions one by one
    % for i = 1 : N
    %     % Select one cluster by Roulette-wheel selection
    %     k = find(rand<=probability,1);%，找到第一个累积概率超过随机数的群集索引。
    %     % Generate one offspring
    %     if ~isempty(Model(k).eVector)
    %         lower = Model(k).a - 0.25*(Model(k).b-Model(k).a);
    %         upper = Model(k).b + 0.25*(Model(k).b-Model(k).a);
    %         trial = rand(1,M-1).*(upper-lower) + lower;%aerfa计算
    %         Structure = Model(k).mean + trial*Model(k).eVector(:,1:M-1)';
    %     else
    %         Structure = Model(k).mean;
    %     end
        
        %% RM Sampling with Differential Perturbation (DP)
        %MatingPool = find(Partition==k);
        % if length(MatingPool) < 3
        %     MatingPool = 1 : N;%k类中种群数少于3，用全部种群
        % end
        [N,D]  = size(pop);
        disM = 20;
        MatingPoolsize = size(MatingPool,1);
        Q = randsample(MatingPoolsize,2);
        r = rand();
        Parent1 = pop(Q(1),:);
        Parent2 = pop(Q(2),:);
        DP = r.*(Parent1 - Parent2);
        y = centroid + DP;


        %% PM as Parent Independent Perturbation
        Lower = min(pop);
        Upper = max(pop);
        Site  = rand(1,D) < 1/D;
        mu    = rand(1,D);
        temp  = Site & mu<=0.5;
        y       = min(max(y,Lower),Upper);%确保了 y 中的每个元素都在 Lower 和 Upper 定义的范围之内
        y(temp) = y(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
            (1-(y(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
        temp = Site & mu>0.5;
        y(temp) = y(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
            (1-(Upper(temp)-y(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
     
end