classdef testGOCEA_beta_eselect < ALGORITHM
% <multi> <real/integer>

    methods
        function main(Algorithm, Problem)
           %% parameter setting
           popSize = Problem.N;
           Kmax = 30;
           BETA = 0.9;
           

           maxGens=Problem.maxFE; %这段新加，一些新的参数初始化
           H=5;
           flg=zeros(popSize,1);
           tmpMatrix=zeros(4,maxGens); % Temporary matrix for beta update
           betaSet=zeros(maxGens+1,1); betaSet(1,1)=BETA;
           gen=0;
           rnd=rand;


           F=0.5;CR=1; 
           objDim=Problem.M;
           varDim=Problem.D;
           pm=1.0/varDim;
           bounds=[Problem.lower;Problem.upper];
           %% Generate random population
           Population = Problem.Initialization();
           pop = Population.decs;
           objVals = Population.objs;
           clustTag=(1:popSize)'; clustName=clustTag; centroid=pop;
           %% Optimization
           while Algorithm.NotTerminated(Population)
               gen=gen+1;
               globalClust=[]; %获取全局子种群
               nClust=size(clustName,1);                                              % Number of clusters
               neigSet=cell(nClust,1);
               

               rndInds=zeros(2,varDim);  %这行新加 为了确保从不同来源分别产生两个解。为了beta的有效性论文中提到
               

               for i=1:nClust
                   mark=clustTag==clustName(i);%找到当前属于第i类的个体编号
                   neigPop=pop(mark,:);
                   pos=randsample(sum(mark),1);
                   globalClust=[neigPop(pos,:);globalClust];%每个类中随机选一个个体加入到全局子种群
                   
                   if sum(mark)>2
                   neigSet(i,1)={neigPop};
                   
                        if sum(rndInds(1,:))==0    %这段新加如果 rndInds的第一行还没有被填充（即没有第一个解被选择），则执行以下操作。
                            pos=randsample(sum(mark),1);%从当前聚类中再次随机选择一个样本。
                            rndInds(1,:)=neigPop(pos,:);%将选择的样本添加到 rndInds 的第一行，作为第一个解。

                        end

                   end
               end
               
               
               pos=randsample(nClust,1);     %这段新加
               rndInds(2,1:varDim)=globalClust(pos,:);%将随机选择的聚类添加到 rndInds 的第二行，作为第二个解
               

               globalSize=size(globalClust,1);
               for i=1:popSize%遍历整个种群中的个体，为每个个体确定其邻居集合
                   currentSol=pop(i,:); currentTag=clustTag(i);
                   neighborhood=neigSet{clustName==currentTag,1};
                   if ~isempty(neighborhood)
                   [~,loc]=ismember(currentSol,neighborhood,'rows');neighborhood(loc,:)=[];% Determine the neighbouring solutions for the current solution
                   end %从邻域中删除当前个体
                   neigSize=size(neighborhood,1);
                   % Select the parents from the neighborhood or the global cluster
                   
                   
                   
                   if ismember(rndInds(1,:),currentSol,'rows')    %这段新加，检查当前解是否等于第一个随机解 rndInds(1,1:varDim)。
                       idx=randsample(neigSize,2); 
                       parents(1:2,1:varDim)=neighborhood(idx,1:varDim);%如果是，从当前解的邻居中随机选择两个解作为父代，并将标志 flg 设置为1。
                       flg(i,1)=1;
                   elseif ismember(rndInds(2,1:varDim),currentSol,'rows')
                       idx=randsample(globalSize,2); 
                       parents(1:2,1:varDim)=globalClust(idx,1:varDim);%如果是，从全局聚类中随机选择两个解作为父代，并将标志 flg 设置为2。
                       flg(i,1)=2;
  

                   
                

                   elseif rnd<BETA    %这段修改如果以上两个条件都不满足，且随机数小于阈值 beta，则执行以下操作。
                       
                       
                       if neigSize>1

                           idx=randsample(neigSize,2); parents(1:2,:)=neighborhood(idx,:); flg(i,1)=1;%这段修改
                       
                       else
                           
                           idx=randsample(globalSize,2); parents(1:2,:)=globalClust(idx,:);flg(i,1)=2;%这段修改
                       
                       end
                   else     %如果以上三个条件都不满足，则执行以下操作。从全局聚类中随机选择两个解作为父代，并将标志 flg 设置为2。
                   idx=randsample(globalSize,2); parents(1:2,:)=globalClust(idx,:);flg(i,1)=2;%这段修改
                   end
                   parents(3,:)=currentSol;
                   trialSol=DifferentialEvolutionCrossover(parents,bounds,F,CR); trialSol=PolynomialMutation(trialSol,bounds,pm);
                   trialVal=Problem.Evaluation(trialSol);
                   auxPop(i,:)=trialSol; auxVals(i,:)=trialVal;

                   auxPop_b(i,1:varDim)=trialSol; auxVals_b(i,1:objDim)=trialVal;%这行新加

               end
                auxObjvs=auxVals.objs;
               [pop,objVals,clustTag,clustName,centroid]=GeOACES(auxPop,auxObjvs,pop,objVals,clustTag,clustName,popSize,objDim,varDim,Kmax);
               
               auxFit=SPEA2Fitness(auxVals_b); %%这段修改 计算适应度
               tmpMatrix(1,gen)=sum(flg==1); tmpMatrix(2,gen)=sum(auxFit(flg==1,1));
               tmpMatrix(3,gen)=sum(flg==2); tmpMatrix(4,gen)=sum(auxFit(flg==2,1));
               epsilon=10^-10;
               if gen<H % 更新beta
                    u1=sum(tmpMatrix(2,1:gen))/sum(tmpMatrix(1,1:gen));
                    u2=sum(tmpMatrix(4,1:gen))/sum(tmpMatrix(3,1:gen));
                    beta=(u2+epsilon)/(u1+u2+epsilon);
               else
                    u1=sum(tmpMatrix(2,gen-H+1:gen))/sum(tmpMatrix(1,gen-H+1:gen));
                    u2=sum(tmpMatrix(4,gen-H+1:gen))/sum(tmpMatrix(3,gen-H+1:gen));
                    beta=(u2+epsilon)/(u1+u2+epsilon);
               end
               betaSet(gen+1,1)=beta;

               Population=Problem.Evaluation(pop);
           end
        end
    end
end